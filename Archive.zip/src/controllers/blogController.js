const Blog = require("../models/Blog");
const fs = require("fs");
const path = require("path");

// ===============================
// List all blogs (index page)
// ===============================
exports.getAllBlogs = async (req, res) => {
  try {
    const blogs = await Blog.find({ isDeleted: false }).populate("user", "username").sort({ createdAt: -1 });
    
    // Render EJS page
    res.render("blogs/index", { blogs, user: req.user, title: "Blogs" });
  } catch (err) {
    console.error("Get Blogs Error:", err);
    req.flash("error", "Unable to fetch blogs");
    res.redirect("/");
  }
};

// ===============================
// Show single blog
// ===============================
exports.getBlogById = async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id).populate("user", "username");
    if (!blog || blog.isDeleted) {
      req.flash("error", "Blog not found");
      return res.redirect("/blogs");
    }
    res.render("blogs/show", { blog, user: req.user });
  } catch (err) {
    console.error("Get Blog Error:", err);
    req.flash("error", "Unable to fetch blog");
    res.redirect("/blogs");
  }
};

// ===============================
// Create new blog
// ===============================
exports.createBlog = async (req, res) => {
  try {
    const { title, content } = req.body;

    // Handle image if uploaded
    const image = req.file ? `/uploads/${req.file.filename}` : undefined;

    const blog = await Blog.create({
      title,
      content,
      image,
      user: req.user._id, // logged-in user
    });

    req.flash("success", "Blog created successfully!");
    res.redirect("/blogs");
  } catch (err) {
    console.error("Create Blog Error:", err);
    req.flash("error", "Failed to create blog");
    res.redirect("/blogs/create");
  }
};

// ===============================
// Render edit blog page
// ===============================
exports.editBlogPage = async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog || (blog.user.toString() !== req.user._id.toString() && !req.user.isAdmin)) {
      req.flash("error", "Not authorized to edit this blog");
      return res.redirect("/blogs");
    }

    res.render("blogs/edit", { blog, user: req.user });
  } catch (err) {
    console.error("Edit Blog Page Error:", err);
    req.flash("error", "Unable to load edit page");
    res.redirect("/blogs");
  }
};

// ===============================
// Update blog
// ===============================
exports.updateBlog = async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog || (blog.user.toString() !== req.user._id.toString() && !req.user.isAdmin)) {
      req.flash("error", "Not authorized to update this blog");
      return res.redirect("/blogs");
    }

    const { title, content } = req.body;

    // If new image uploaded, delete old image
    if (req.file) {
      if (blog.image) {
        const oldPath = path.join(__dirname, "../../public", blog.image);
        if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
      }
      blog.image = `/uploads/${req.file.filename}`;
    }

    blog.title = title;
    blog.content = content;

    await blog.save();

    req.flash("success", "Blog updated successfully!");
    res.redirect(`/blogs/${blog._id}`);
  } catch (err) {
    console.error("Update Blog Error:", err);
    req.flash("error", "Failed to update blog");
    res.redirect(`/blogs/edit/${req.params.id}`);
  }
};

// ===============================
// Delete blog
// ===============================
exports.deleteBlog = async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) {
      req.flash("error", "Blog not found");
      return res.redirect("/blogs");
    }

    // User: soft delete, Admin: hard delete
    if (req.user.isAdmin) {
      if (blog.image) {
        const imgPath = path.join(__dirname, "../../public", blog.image);
        if (fs.existsSync(imgPath)) fs.unlinkSync(imgPath);
      }
      await blog.deleteOne();
    } else {
      if (blog.user.toString() !== req.user._id.toString()) {
        req.flash("error", "Not authorized to delete this blog");
        return res.redirect("/blogs");
      }
      blog.isDeleted = true;
      await blog.save();
    }

    req.flash("success", "Blog deleted successfully!");
    res.redirect("/blogs");
  } catch (err) {
    console.error("Delete Blog Error:", err);
    req.flash("error", "Failed to delete blog");
    res.redirect("/blogs");
  }
};
