const User = require("../models/User");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const Blog = require("../models/Blog");

// Generate JWT
const generateToken = (user) => {
  return jwt.sign(
    { id: user._id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: "1d" }
  );
};

// Register
exports.register = async (req, res) => {
  try {
    const { username, email, password } = req.body;

    // Check if all fields exist
    if (!username || !email || !password) {
      req.flash("error", "All fields are required");
      return res.redirect("/register");
    }

    // Check if user exists
    const userExists = await User.findOne({ email });
    if (userExists) {
      req.flash("error", "User already exists");
      return res.redirect("/register");
    }

    // Handle profile image
    const profileImage = req.file ? `/uploads/${req.file.filename}` : undefined;

    const user = await User.create({
      username,
      email,
      password,
      profileImage,
    });

    req.flash("success", "Registration successful! Please login.");
    res.redirect("/login");
  } catch (err) {
    console.error("Registration Error:", err);
    req.flash("error", "Registration failed");
    res.redirect("/register");
  }
};


// Login
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user || !(await user.matchPassword(password))) {
      req.flash("error", "Invalid email or password");
      return res.redirect("/login");
    }

    const token = generateToken(user);
    res.cookie("token", token, { httpOnly: true });

    req.flash("success", "Logged in successfully");
    res.redirect("/dashboard");
  } catch (err) {
    console.error(err);
    req.flash("error", "Login failed");
    res.redirect("/login");
  }
};

// Logout
exports.logout = async (req, res) => {
  res.clearCookie("token");
  req.flash("success", "Logged out successfully");
  res.redirect("/login");
};

