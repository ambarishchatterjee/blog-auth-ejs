const jwt = require("jsonwebtoken");
const User = require("../models/User");

// Protect routes
exports.protect = async (req, res, next) => {
  const token = req.cookies.token;

  if (!token) {
    req.flash("error", "Not authorized, please login");
    return res.redirect("/login");
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id).select("-password");
    next();
  } catch (err) {
    console.error(err);
    req.flash("error", "Session expired, please login again");
    res.redirect("/login");
  }
};
